
use_new_llvm=true

llvm362=/home/seviezhou/package/clang-3.6.2/bin
llvm8=/home/seviezhou/package/clang-8/bin

function makeall {

    python3 create_per_cwe_files.py CWE True
    python3 run_analysis_example_tool.py

    mkdir -p binaries

    for exe in `find ./testcases -type f -executable -print`
    do
        cp $exe binaries/
    done
}

function makeallwllvm {

    sed -i -e "s/CC=\/usr\/bin\/gcc/CC=wllvm/g" create_per_cwe_files.py
    sed -i -e "s/CPP=\/usr\/bin\/g++/CPP=wllvm++/g" create_per_cwe_files.py

    for file in `find ./testcases -name "Makefile" -print`; 
    do 
        sed -i -e "s/CC=\/usr\/bin\/gcc/CC=wllvm/g" $file
        sed -i -e "s/CPP=\/usr\/bin\/g++/CPP=wllvm++/g" $file
    done

    if [ "$use_new_llvm" = true ] ; then
        export PATH=$llvm8:$PATH
    else
        export PATH=$llvm362:$PATH
    fi

    export LLVM_COMPILER=clang

    USE_CC=wllvm
    USE_CXX=wllvm++    

    python3 create_per_cwe_files.py CWE True
    python3 run_analysis_example_tool.py

    mkdir -p binaries

    for exe in `find ./testcases -type f -executable -print`
    do
        cp $exe binaries/
    done

    for file in `ls binaries/` 
    do
        extract-bc binaries/$file
        echo "$file"
    done

    for file in `find ./testcases -name "Makefile" -print`; 
    do 
        sed -i -e "s/CC=wllvm/CC=\/usr\/bin\/gcc/g" $file
        sed -i -e "s/CPP=wllvm++/CPP=\/usr\/bin\/g++/g" $file
    done

    sed -i -e "s/CC=wllvm/CC=\/usr\/bin\/gcc/g" create_per_cwe_files.py
    sed -i -e "s/CPP=wllvm++/CPP=\/usr\/bin\/g++/g" create_per_cwe_files.py
}

#function verify {

    # if [ "$#" -eq 1 ]; then
    #     report_path=$1
    # else
    #     echo "Has to provide report path."
    #     exit
    # fi

    # for report in `ls ${report_path}/*.txt`
    # do
    #     name=`basename $report`
    #     cwe=`echo $name | awk -F"_" '{print $1}' | awk -F"." '{print $1}' | awk -F"CWE" '{print $2}'`
    #     cwe=CWE-$cwe
    #     cat $report | grep $cwe
    # done
#}

"$@"
