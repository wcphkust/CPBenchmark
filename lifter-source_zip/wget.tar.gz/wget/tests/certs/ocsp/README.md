Generating Certificates and Responses
===

The scripts use:
* GnuTLS (certtool)
* openssl (ca, ocsp)

## Generate Certificates
`$ bash generate_certs.sh`

## Generate Responses
`$ bash generate_resp.sh`

## Generate Stapled Response
`$ bash generate_stap.sh`
