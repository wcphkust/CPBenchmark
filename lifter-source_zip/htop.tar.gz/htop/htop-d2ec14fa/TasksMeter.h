#ifndef HEADER_TasksMeter
#define HEADER_TasksMeter
/*
htop - TasksMeter.h
(C) 2004-2011 Hisham H. Muhammad
Released under the GNU GPLv2+, see the COPYING file
in the source distribution for its full text.
*/

#include "Meter.h"


extern const MeterClass TasksMeter_class;

#endif
