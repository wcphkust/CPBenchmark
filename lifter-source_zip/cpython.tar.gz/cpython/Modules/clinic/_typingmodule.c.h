/*[clinic input]
preserve
[clinic start generated code]*/

PyDoc_STRVAR(_typing__idfunc__doc__,
"_idfunc($module, x, /)\n"
"--\n"
"\n");

#define _TYPING__IDFUNC_METHODDEF    \
    {"_idfunc", (PyCFunction)_typing__idfunc, METH_O, _typing__idfunc__doc__},
/*[clinic end generated code: output=e7ea2a3cb7ab301a input=a9049054013a1b77]*/
