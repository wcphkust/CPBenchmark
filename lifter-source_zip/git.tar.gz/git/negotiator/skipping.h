#ifndef NEGOTIATOR_SKIPPING_H
#define NEGOTIATOR_SKIPPING_H

struct fetch_negotiator;

void skipping_negotiator_init(struct fetch_negotiator *negotiator);

#endif
