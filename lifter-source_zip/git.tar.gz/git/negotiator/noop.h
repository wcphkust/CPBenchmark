#ifndef NEGOTIATOR_NOOP_H
#define NEGOTIATOR_NOOP_H

struct fetch_negotiator;

void noop_negotiator_init(struct fetch_negotiator *negotiator);

#endif
