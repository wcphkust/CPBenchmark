#ifndef __utils_h__
#define __utils_h__
char* concatPaths(const char*base, const char*add);
#endif
