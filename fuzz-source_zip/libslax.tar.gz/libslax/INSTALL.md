<!---
# $Id$
#
# Copyright 2013, Juniper Networks, Inc.
# All rights reserved.
# This SOFTWARE is licensed under the LICENSE provided in the
# ../Copyright file. By downloading, installing, copying, or otherwise
# using the SOFTWARE, you agree to be bound by the terms of that
# LICENSE.
#-->

## Instructions for building libslax

Instructions for building libslax are now available in the
[wiki](https://github.com/Juniper/libslax/wiki/Building).
