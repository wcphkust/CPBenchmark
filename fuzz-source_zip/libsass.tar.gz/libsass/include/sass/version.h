#ifndef SASS_VERSION_H
#define SASS_VERSION_H

#ifndef LIBSASS_VERSION
#define LIBSASS_VERSION "3.6.4-11-gb916-dirty"
#endif

#ifndef LIBSASS_LANGUAGE_VERSION
#define LIBSASS_LANGUAGE_VERSION "3.5"
#endif

#endif
