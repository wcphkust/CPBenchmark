#ifndef SASSC_VERSION_H
#define SASSC_VERSION_H

#ifndef SASSC_VERSION
#define SASSC_VERSION "[NA]"
#endif

#endif
