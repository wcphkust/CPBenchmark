module SassSpec
  module Annotate
  end
end

require_relative "annotate/cli"
