"Simple" as in "simple selectors", not as in "simple test cases".
