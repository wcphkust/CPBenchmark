Escaped code points in identifiers are converted to a normal form but left as
escapes, so that they're distinct from unquoted strings that contain raw
characters.
