In an effort to improve the quality of `sass-spec`, all specs that pre-date the
style guide have been moved to this directory. These specs should remain here
until they are refactored to follow the style guide. They can be used as a
starting point for standalone specs or to flesh out existing specs outside of
`non_conformant/`.
