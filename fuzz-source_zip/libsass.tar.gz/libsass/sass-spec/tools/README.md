## gen_libsass_todo

```bash
$ gen_libsass_todo # [remote]
$ gen_libsass_todo 2014 mgreter
```

- create a new branch from master
- read spec test from `$ISSUE.scss`
- create folder and necessary files
- call spec runner to generate the test
- add files to git and create commit
- optionally push to the given remote
