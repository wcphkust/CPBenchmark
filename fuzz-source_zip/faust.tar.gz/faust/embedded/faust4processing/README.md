# faust4processing : a Faust library for processing

- you'll need the [swig](http://swig.org) tool
- you'll need to have **faust** compiled and installed
- check and change if needed the location of Processing in the Makefile
- then use **make** and **make install**
