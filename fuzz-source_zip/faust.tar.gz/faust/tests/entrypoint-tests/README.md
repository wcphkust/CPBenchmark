
# Test the `--process-name` option #

Run the `tests` command:

./tests


