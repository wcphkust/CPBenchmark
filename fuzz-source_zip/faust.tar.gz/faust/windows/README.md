
# Windows resources #

This folder contains Windows specific resources. It includes binary versions of libmicrohttpd.
