See the [Atom contributing guide](https://atom.io/docs/latest/contributing)
