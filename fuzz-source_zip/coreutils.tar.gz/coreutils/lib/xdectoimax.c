#define __xdectoint xdectoimax
#define __xnumtoint xnumtoimax
#define __xdectoint_t intmax_t
#define __xstrtol xstrtoimax
#define __xdectoint_signed 1
#include "xdectoint.c"
