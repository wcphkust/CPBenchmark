#define __xdectoint xdectoumax
#define __xnumtoint xnumtoumax
#define __xdectoint_t uintmax_t
#define __xstrtol xstrtoumax
#define __xdectoint_signed 0
#include "xdectoint.c"
