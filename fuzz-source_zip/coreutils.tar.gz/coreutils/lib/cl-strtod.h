double cl_strtod (char const *, char **restrict);
long double cl_strtold (char const *, char **restrict);
