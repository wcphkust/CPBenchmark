
// I wish to incur DLL exporting on the main interface classes.

// It should THEORETICALLY be enough to do this:

#include "interface/tagitem.hpp" 

// See j2kdll.cpp

#include "interface/tagitem.cpp"
