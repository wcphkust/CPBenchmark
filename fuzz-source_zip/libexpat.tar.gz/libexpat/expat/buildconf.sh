#! /bin/sh
exec autoreconf --warnings=all --install --verbose "$@"
