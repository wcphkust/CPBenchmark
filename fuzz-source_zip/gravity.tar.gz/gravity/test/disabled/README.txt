- loop1.gravity has been disabled because it is not possible to detect such infinite loop. For more information https://www.quora.com/Is-it-possible-to-detect-and-stop-an-infinite-loop-when-writing-a-program

- heap.gravity needs further investigation but I suspect it cannot be detected too