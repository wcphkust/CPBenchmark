## A collection of optional classes for the Gravity programming language
