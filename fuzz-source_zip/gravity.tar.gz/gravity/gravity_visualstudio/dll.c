#include <windows.h>

BOOL WINAPI DllMain(HINSTANCE _1, DWORD _2, LPVOID _3) {
  return TRUE;
}