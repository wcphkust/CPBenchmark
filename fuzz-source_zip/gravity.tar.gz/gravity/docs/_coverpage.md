<p align="center">
<img src="assets/images/logo.png" height="90px" alt="Gravity Programming Language" title="Gravity Programming Language">
</p>

# Gravity <small>0.78</small>
> An embeddable programming language.

* Simple and lightweight
* No external dependencies
* Register based virtual machine

[GitHub](https://github.com/marcobambini/gravity)
[Get Started](README.md)
