### Bool

The Bool data type can have only two values, they are the literals true and false. A Bool value expresses the validity of a condition (tells whether the condition is true or false).
```swift
	var a = true;
	var b = false;
```
