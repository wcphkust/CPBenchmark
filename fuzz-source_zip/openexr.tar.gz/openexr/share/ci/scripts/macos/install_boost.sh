#!/usr/bin/env bash

set -ex

brew update
brew install boost
brew install boost-python
brew install boost-python3
