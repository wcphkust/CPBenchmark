Welcome to Bento4
======================
![](images/tokyometro.jpg)

Bento4 MP4, DASH/HLS/CMAF Class Library, SDK and Tools
------------------------------------------------------

A fast, modern, open source C++ toolkit for all your MP4 and DASH/HLS/CMAF media format needs